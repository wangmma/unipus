<h1>Uer</h1>
<h1>该脚本修改于U校园网课显示</h1>
<ul>
<li>有问题请反馈</li>
<a href="https://greasyfork.org/zh-CN/forum/post/discussion?script=397517" title="打开链接" rel="nofollow"><strong>点击反馈</strong></a>
<li>或加群 Uer Tg群: https://t.me/uxyer</li>
<a href="https://jq.qq.com/?_wv=1027&k=54Sj7yE" title="打开链接" rel="nofollow"><strong>Q群：【Uer交流群】</strong></a>
<li>感谢以下作者提供的帮助</li>
<a href="https://greasyfork.org/zh-CN/users/265528-demcorazy" title="打开链接" rel="nofollow"><strong>感谢domooc作者ExTedic</strong></a>
<a href="https://greasyfork.org/zh-CN/users/192495-codfrm" title="打开链接" rel="nofollow"><strong>感谢超星小工具作者wyz</strong></a>
<a href="https://greasyfork.org/zh-CN/users/291023-askar882" title="打开链接" rel="nofollow"><strong>代码修改于askar882</strong></a>
</ul>
<h1>说明</h1>
<li>为了维护服务器与脚本日常开发</li>
<p>1.于2020年4月11日起测试类相关题目开始收费</p>
<p>2.详细加群了解</p>
<h1>更新日志</h1>
<ul>
<li>V1.9测试中</li>
<p>1.UI重构</p>
<p>2.解析重构</p>
<p>3.支持视听说单元测试</p>
<p>4.支持课程测试与作业</p>
<li>V1.8</li>
<p>1.8.7修复乱序</p>
<p>有人反馈答题过快</p>
<p>加入每题之间答题间隔【默认随机1-3秒】</p>
<p>在代码中调整max 与 min的值</p>
<li>V1.6</li>
<p>加入自动答题开关[默认开启]</p>
<p>在代码中修改hasInput变量，底部有图片示例</p>
</ul>
<h1>注意事项</h1>
<ul>
<li>出现答题失败的可能原因：</li>
<li>1.该题型未适配</li>
<li>2.网页存在缓存，刷新网页即可</li>
<li>如有疑问，请反馈。</li>
</ul>
<hr><h1>声明</h1>
<p>使用脚本则同意以下规定<br>代码禁止二次开发<br>本软件按“原样”提供，不提供任何形式的明示或暗示担保，包括但不限于对适销性，特定目的的适用性和非侵权性的担保。无论是由于软件，使用或其他方式产生的，与之有关或与之有关的合同，侵权或其他形式的任何索赔，损害或其他责任，作者或版权所有者概不负责。软件<br></p>
</div>
